clear; clc;

%% Parâmetros do CSTR
V    = 1.0;          % m3
CAin = 1.0;          % kmol/m3
Tin  = 350;          % K
Tc   = 300;          % K


rho = 1000;          % kg/m3
Cp  = 4.18;          % kJ/kg/K

k0 = 7.2e10;         % 1/min
E  = 8.314e4;        % kJ/kmol
R  = 8.314;          % kJ/kmol/K

dH = -5.0e7;         % kJ/kmol
UA = 5.0e4;          % kJ/min/K

%% Variáveis medidas: [Fin; Fout; CA; T]
y_meas = [1.05;      % Fin, m3/min
          0.97;      % Fout, m3/min
          0.42;      % CA, kmol/m3
          365];      % T, K 

%% Incertezas-padrão de medição
sigma = [0.2;       % Fin
         0.2;       % Fout
         0.01;       % CA
         1.0];       % T

W = diag(1./sigma.^2);

%% Função objetivo WLS
obj = @(y) (y - y_meas)'*W*(y - y_meas);

%% Restrições dos balanços
nonlcon = @(y) cstr_balances_reconciliation(y,V,CAin,Tin,Tc,...
                                            rho,Cp,k0,E,R,dH,UA);

%% Limites físicos
lb = [0.1; 0.1; 0.001; 280];
ub = [5.0; 5.0; CAin; 500];

%% Chute inicial
y0 = y_meas;

%% Otimização
% opts = optimoptions('fmincon',...
%     'Display','iter',...
%     'Algorithm','sqp',...
%     'ConstraintTolerance',1e-9,...
%     'OptimalityTolerance',1e-9);

[y_rec,J_rec] = fmincon(obj,y0,[],[],[],[],lb,ub,nonlcon,[]);

%% Tabela de resultados
variavel = ["Fin"; "Fout"; "CA"; "T"];

medido = y_meas;
reconciliado = y_rec;
desvio_abs = y_rec - y_meas;
desvio_rel = 100*(y_rec - y_meas)./y_meas;

Tabela = table(variavel, medido, reconciliado, desvio_abs, desvio_rel)

%% Resíduos dos balanços antes e depois
[~, ceq_meas] = cstr_balances_reconciliation(y_meas,V,CAin,Tin,Tc,...
                                             rho,Cp,k0,E,R,dH,UA);

[~, ceq_rec] = cstr_balances_reconciliation(y_rec,V,CAin,Tin,Tc,...
                                            rho,Cp,k0,E,R,dH,UA);

Balanco = ["Massa global"; "Componente A"; "Energia"];

TabelaBalancos = table(Balanco, ceq_meas, ceq_rec)