%% CLASSICAL RTO APPLIED TO A CSTR SYSTEM
% Steps:
% 1) Plant simulation with noisy measurements
% 2) Steady-state identification
% 3) Data reconciliation
% 4) Parameter estimation
% 5) Real-Time Optimization
%
% Reaction: A -> B
% Rate: rA = k0*exp(-E/(R*T))*CA
%
% States:
% CA = concentration of A [mol/L]
% T  = reactor temperature [K]
%
% Manipulated variables:
% F  = inlet flow rate [L/min]
% Tc = coolant temperature [K]

clear; clc; close all;

%% Parameters: nominal model
par.V     = 100;       % L
par.CAf   = 1.0;       % mol/L
par.Tf    = 350;       % K
par.k0    = 7.2e10;    % 1/min
par.EoverR = 8750;     % K
par.dH    = -5e4;      % J/mol
par.rhoCp = 4.2e3;     % J/(L K)
par.UA    = 5e4;       % J/(min K)

%% True plant parameters
plant = par;
plant.k0 = 8.0e10;     % plant/model mismatch

%% Current operation
u_current.F  = 100;    % L/min
u_current.Tc = 300;    % K

x0 = [0.7; 330];       % initial condition: [CA; T]

%% Simulate plant
tspan = [0 80];
[t,x] = ode45(@(t,x)cstr_ode(t,x,u_current,plant),tspan,x0);

CA_true = x(:,1);
T_true  = x(:,2);

%% Generate noisy measurements
rng(1)

sigma_CA = 0.01;
sigma_T  = 0.5;

CA_meas = CA_true + sigma_CA*randn(size(CA_true));
T_meas  = T_true  + sigma_T*randn(size(T_true));

%% Plot plant data
figure;
plot(t,CA_meas,'o'); hold on;
plot(t,CA_true,'LineWidth',2);
xlabel('Time [min]');
ylabel('C_A [mol/L]');
legend('Measured','True');
title('CSTR concentration response');

figure;
plot(t,T_meas,'o'); hold on;
plot(t,T_true,'LineWidth',2);
xlabel('Time [min]');
ylabel('Temperature [K]');
legend('Measured','True');
title('CSTR temperature response');

%% 1) Steady-state identification using Cao-Rhinehart type statistic

% MSD  = mean squared deviation from filtered mean
% MSSD = mean squared successive difference / 2
%
% R = MSD / MSSD
%
% At steady state, R is close to 1.
% During transients, R becomes larger than 1.

alpha = 0.08;      % forgetting factor for recursive statistics
Rcrit = 5;       % critical value; typical tuning: 1.2 to 2.5
N_hold = 8;        % number of consecutive samples required

n = length(t);

% Initialize filtered means
mu_CA = zeros(n,1);
mu_T  = zeros(n,1);

mu_CA(1) = CA_meas(1);
mu_T(1)  = T_meas(1);

% Initialize MSD and MSSD
MSD_CA  = zeros(n,1);
MSSD_CA = zeros(n,1);

MSD_T  = zeros(n,1);
MSSD_T = zeros(n,1);

R_CA = nan(n,1);
R_T  = nan(n,1);

ss_candidate = false(n,1);

eps_reg = 1e-12;

for k = 2:n

    % Previous filtered means
    mu_CA_old = mu_CA(k-1);
    mu_T_old  = mu_T(k-1);

    % Update filtered means
    mu_CA(k) = alpha*CA_meas(k) + (1-alpha)*mu_CA(k-1);
    mu_T(k)  = alpha*T_meas(k)  + (1-alpha)*mu_T(k-1);

    % Mean squared deviation from previous filtered mean
    MSD_CA(k) = alpha*(CA_meas(k) - mu_CA_old)^2 ...
              + (1-alpha)*MSD_CA(k-1);

    MSD_T(k) = alpha*(T_meas(k) - mu_T_old)^2 ...
             + (1-alpha)*MSD_T(k-1);

    % Mean squared successive difference
    MSSD_CA(k) = alpha*((CA_meas(k) - CA_meas(k-1))^2/2) ...
               + (1-alpha)*MSSD_CA(k-1);

    MSSD_T(k) = alpha*((T_meas(k) - T_meas(k-1))^2/2) ...
              + (1-alpha)*MSSD_T(k-1);

    % Rhinehart-type ratio
    R_CA(k) = MSD_CA(k)/(MSSD_CA(k) + eps_reg);
    R_T(k)  = MSD_T(k)/(MSSD_T(k) + eps_reg);

    % Multivariable decision: all relevant variables must be steady
    if R_CA(k) < Rcrit && R_T(k) < Rcrit
        ss_candidate(k) = true;
    end

end

% Require persistence of the decision
ss_flag = false(n,1);

for k = N_hold:n
    if all(ss_candidate(k-N_hold+1:k))
        ss_flag(k) = true;
    end
end

idx_ss = find(ss_flag,1,'first');

if isempty(idx_ss)
    error('No steady state detected. Adjust alpha, Rcrit, or N_hold.');
end

fprintf('\nSteady state detected by Rhinehart-type method at t = %.2f min\n',t(idx_ss));

CA_ss_meas = mean(CA_meas(idx_ss:end));
T_ss_meas  = mean(T_meas(idx_ss:end));

y_meas = [CA_ss_meas; T_ss_meas];

fprintf('Measured steady state:\n');
fprintf('CA = %.4f mol/L\n',CA_ss_meas);
fprintf('T  = %.2f K\n',T_ss_meas);

%% Diagnostic plots

figure;
plot(t,CA_meas,'o'); hold on;
plot(t,mu_CA,'LineWidth',2);
xline(t(idx_ss),'--','Steady state detected');
xlabel('Time [min]');
ylabel('C_A [mol/L]');
legend('Measured','Filtered mean','Location','best');
title('Rhinehart-type steady-state detection - C_A');

figure;
plot(t,T_meas,'o'); hold on;
plot(t,mu_T,'LineWidth',2);
xline(t(idx_ss),'--','Steady state detected');
xlabel('Time [min]');
ylabel('Temperature [K]');
legend('Measured','Filtered mean','Location','best');
title('Rhinehart-type steady-state detection - T');

figure;
plot(t,R_CA,'LineWidth',2); hold on;
plot(t,R_T,'LineWidth',2);
yline(Rcrit,'--','R_{crit}');
xline(t(idx_ss),'--','Steady state detected');
xlabel('Time [min]');
ylabel('Rhinehart-type statistic R');
legend('R_{CA}','R_T','R_{crit}','Location','best');
title('Steady-state detection statistic');
grid on;
%% 2) Data reconciliation
% Reconcile measurements by enforcing steady-state model constraints.
%
% Decision variables:
% z = [CA, T]
%
% Objective:
% minimize weighted measurement deviation
%
% Constraint:
% steady-state model equations = 0 mass and energy balances

W = diag([1/sigma_CA^2, 1/sigma_T^2]); % covariance matrix (measurement uncertainties)

z_meas_ss = y_meas;

obj_recon = @(z) (z-y_meas)'*W*(z-y_meas);

nonlcon_recon = @(z)cstr_ss_constraints(z,u_current,par);

opts = optimoptions('fmincon',...
    'Display','iter',...
    'Algorithm','sqp');

lb_z = [0.001; 280];
ub_z = [2.000; 500];

[z_rec, J_rec] = fmincon(obj_recon,z_meas_ss,[],[],[],[],lb_z,ub_z,nonlcon_recon,opts);

CA_rec = z_rec(1);
T_rec  = z_rec(2);

% Relative deviation (%)
dev_CA = 100*(CA_rec - CA_ss_meas)/CA_ss_meas;
dev_T  = 100*(T_rec  - T_ss_meas )/T_ss_meas;

% Relative uncertainty
uR_CA = 100*sigma_CA / CA_ss_meas;
uR_T =  100*sigma_T / T_ss_meas;

% Build table
VarName = {'CA'; 'T'};
Measured = [CA_ss_meas; T_ss_meas];
Reconciled = [CA_rec; T_rec];
StdUncertainty=[sigma_CA; sigma_T];
RelError = [dev_CA; dev_T];
RelUnc = [uR_CA; uR_T];

T_report = table(Measured, Reconciled, StdUncertainty, RelError, RelUnc, ...
    'RowNames', VarName);

disp(' ');
disp('===== DATA RECONCILIATION REPORT =====');
disp(T_report);

%% 3) Parameter estimation
% Estimate k0 using reconciled steady-state data.
%
% Here, only k0 is estimated.
% In a real RTO layer, several parameters may be estimated.

theta0 = par.k0;
% theta0 = plant.k0;

obj_est = @(theta) parameter_estimation_objective(theta,z_rec,u_current,par,W);

lb_theta = 1e9;
ub_theta = 1e12;

[theta_est, fval, flag, out] = fmincon(obj_est,theta0,[],[],[],[],lb_theta,ub_theta,[],opts);

par_est = par; % update
par_est.k0 = theta_est; % update with optimal theta

fprintf('\nEstimated parameter:\n');
fprintf('k0 nominal   = %.3e 1/min\n',par.k0);
fprintf('k0 true      = %.3e 1/min\n',plant.k0);
fprintf('k0 estimated = %.3e 1/min\n',theta_est);

%% 4) Classical steady-state RTO
% Economic objective:
% maximize profit = value of B - cost of cooling - flow penalty
%
% Since B is produced from A, at steady-state:
% CB = CAf - CA
%
% Profit = pB*F*(CAf - CA) - cQ*(UA*(T - Tc)) - cF*F
%
% Optimization variables:
% decision = [F, Tc]
%
% State variables are obtained from steady-state model.

u0 = [u_current.F; u_current.Tc];

lb_u = [40; 280];
ub_u = [160; 330];

obj_rto = @(u) -economic_profit(u,par_est);

nonlcon_rto = @(u)rto_constraints(u,par_est);

[u_opt, neg_profit_opt] = fmincon(obj_rto,u0,[],[],[],[],lb_u,ub_u,nonlcon_rto,opts);

F_opt  = u_opt(1);
Tc_opt = u_opt(2);

profit_current = economic_profit([u_current.F; u_current.Tc],par_est);
profit_opt     = -neg_profit_opt;

fprintf('\nRTO result:\n');
fprintf('Current F  = %.2f L/min\n',u_current.F);
fprintf('Current Tc = %.2f K\n',u_current.Tc);
fprintf('Optimal F  = %.2f L/min\n',F_opt);
fprintf('Optimal Tc = %.2f K\n',Tc_opt);

fprintf('\nEconomic performance:\n');
fprintf('Current profit = %.4f\n',profit_current);
fprintf('Optimal profit = %.4f\n',profit_opt);

%% Compare steady states
[xss_current,~] = solve_cstr_ss([u_current.F; u_current.Tc],par_est);
[xss_opt,~]     = solve_cstr_ss(u_opt,par_est);

fprintf('\nPredicted steady states:\n');
fprintf('Current: CA = %.4f, T = %.2f K\n',xss_current(1),xss_current(2));
fprintf('Optimal: CA = %.4f, T = %.2f K\n',xss_opt(1),xss_opt(2));

%% Plot economic comparison
figure;
bar([profit_current profit_opt]);
set(gca,'XTickLabel',{'Current','RTO optimum'});
ylabel('Profit');
title('Classical RTO economic improvement');

%% ===============================================================
% Local functions
% ===============================================================

function dxdt = cstr_ode(~,x,u,par)

    CA = x(1);
    T  = x(2);

    F  = u.F;
    Tc = u.Tc;

    k = par.k0*exp(-par.EoverR/T);
    rA = k*CA;

    dCA = F/par.V*(par.CAf - CA) - rA;

    dT = F/par.V*(par.Tf - T) ...
        + (-par.dH/par.rhoCp)*rA ...
        - par.UA/(par.V*par.rhoCp)*(T - Tc);

    dxdt = [dCA; dT];

end

function [c,ceq] = cstr_ss_constraints(z,u,par)

    CA = z(1);
    T  = z(2);

    F  = u.F;
    Tc = u.Tc;

    k = par.k0*exp(-par.EoverR/T);
    rA = k*CA;

    ceq1 = F/par.V*(par.CAf - CA) - rA;

    ceq2 = F/par.V*(par.Tf - T) ...
         + (-par.dH/par.rhoCp)*rA ...
         - par.UA/(par.V*par.rhoCp)*(T - Tc);

    ceq = [ceq1; ceq2];
    c = [];

end

function J = parameter_estimation_objective(theta,z_meas,u,par,W)

    par_tmp = par;
    par_tmp.k0 = theta;

    [z_pred,exitflag] = solve_cstr_ss([u.F; u.Tc],par_tmp);

    if exitflag <= 0
        J = 1e10;
        return;
    end

    e = z_pred - z_meas;
    J = e'*W*e;

end

function profit = economic_profit(u,par)

    [xss,exitflag] = solve_cstr_ss(u,par);

    if exitflag <= 0
        profit = -1e10;
        return;
    end

    CA = xss(1);
    T  = xss(2);

    F  = u(1);
    Tc = u(2);

    CB = par.CAf - CA;

    pB = 120;       % product value
    cQ = 1e-4;      % heat utility cost
    cF = 0.05;      % feed/pumping cost

    Q = par.UA*(T - Tc);

    profit = pB*F*CB - cQ*abs(Q) - cF*F;

end

function [c,ceq] = rto_constraints(u,par)

    [xss,exitflag] = solve_cstr_ss(u,par);

    if exitflag <= 0
        c = 1e6;
        ceq = [];
        return;
    end

    CA = xss(1);
    T  = xss(2);

    % Safety and operability constraints
    Tmax = 390;
    CAmin = 0.05;

    c1 = T - Tmax;
    c2 = CAmin - CA;

    c = [c1; c2];
    ceq = [];

end

function [xss,exitflag] = solve_cstr_ss(u,par)

    F  = u(1);
    Tc = u(2);

    z0 = [0.5; 360];

    fun = @(z)cstr_ss_residual(z,F,Tc,par);

    opts = optimoptions('fsolve',...
        'Display','off',...
        'FunctionTolerance',1e-10,...
        'StepTolerance',1e-10);

    [xss,~,exitflag] = fsolve(fun,z0,opts);

end

function res = cstr_ss_residual(z,F,Tc,par)

    CA = z(1);
    T  = z(2);

    k = par.k0*exp(-par.EoverR/T);
    rA = k*CA;

    res1 = F/par.V*(par.CAf - CA) - rA;

    res2 = F/par.V*(par.Tf - T) ...
         + (-par.dH/par.rhoCp)*rA ...
         - par.UA/(par.V*par.rhoCp)*(T - Tc);

    res = [res1; res2];

end