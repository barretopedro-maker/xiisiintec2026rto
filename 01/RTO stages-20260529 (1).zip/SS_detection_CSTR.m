%% CSTR steady-state detection example
% Non-isothermal CSTR
% A -> B (elementary reaction)
% Methods:
% 1) Slope test
% 2) Variance ratio test

clear; clc; close all;

%% ------------------------ Model parameters ------------------------------
p.V     = 100;          % reactor volume [L]
p.F     = 100;          % flow rate [L/min]
p.k0    = 7.2e10;       % pre-exponential factor [1/min]
p.E_R   = 8750;         % E/R [K]
p.dH    = -5e4;         % heat of reaction [J/mol]
p.rhoCp = 5e4;          % volumetric heat capacity [J/(L.K)]
p.UA    = 5e4;          % heat transfer coefficient*area [J/(min.K)]
p.Tc    = 300;          % coolant temperature [K]

% Initial feed conditions
p.CAin1 = 1.0;          % initial feed concentration [mol/L]
p.CAin2 = 1.2;          % stepped feed concentration [mol/L]
p.Tin   = 350;          % feed temperature [K]

% Step time
t_step = 5.0;           % [min]

%% ------------------------ Simulation setup ------------------------------
tspan = [0 20];         % [min]
x0    = [0.50; 350];    % initial condition [CA, T]

opts = odeset('RelTol',1e-7,'AbsTol',1e-9);

[t, x] = ode45(@(t,x) cstr_ode(t, x, p, t_step), tspan, x0, opts);

CA = x(:,1);
T  = x(:,2);

%% ------------------------ Measured signal -------------------------------
rng(10);                % reproducibility (seed)
sigma_noise = 0.001;     % measurement noise std [mol/L]
z = CA + sigma_noise*randn(size(CA));

%% ------------------------ Detection parameters --------------------------
Nw = 20;                % moving window length for slope/variance tests
if Nw >= numel(t)/3
    error('Window length Nw is too large for the current simulation.');
end

% Variance-ratio filtered method parameters
lambda1 = 0.2;
lambda2 = 0.2;
lambda3 = 0.2;
Rcrit   = 2.5;

%% ------------------------ 1) Slope test --------------------------------
slope = nan(size(z));
slope_flag = false(size(z)); % true = accepted as SS by slope criterion

b_max = 0.01; % threshold on absolute slope [mol/L/min]

for k = Nw:numel(z)
    idx = (k-Nw+1):k;
    tk = t(idx);
    yk = z(idx);

    % linear regression
    pfit = polyfit(tk, yk, 1);
    slope(k) = pfit(1);
    slope_flag(k) = abs(slope(k)) < b_max;
end

%% ------------------------ 2) Variance ratio test ------------------------
% Filtered variance ratio similar to the equation you sent:
% z_f(k)       = lambda1*z(k) + (1-lambda1)*z(k-1)
% delta1_f^2   = lambda2*(z(k)-z_f(k-1))^2 + (1-lambda2)*delta1_f(k-1)^2
% delta2_f^2   = lambda3*(z(k)-z(k-1))^2   + (1-lambda3)*delta2_f(k-1)^2
% R_SS         = (2-lambda1)*delta1_f^2 / delta2_f^2

zf      = nan(size(z));
delta1  = nan(size(z));
delta2  = nan(size(z));
RSS     = nan(size(z));
vr_flag = false(size(z)); % true = accepted as SS by variance-ratio criterion

% Initialization
zf(1)     = z(1);
delta1(1) = 0;
delta2(1) = 0;

for k = 2:numel(z)
    zf(k) = lambda1*z(k) + (1-lambda1)*z(k-1);

    delta1(k) = lambda2*(z(k) - zf(k-1))^2 + (1-lambda2)*delta1(k-1);
    delta2(k) = lambda3*(z(k) - z(k-1))^2 + (1-lambda3)*delta2(k-1);

    if delta2(k) > eps
        RSS(k) = (2 - lambda1)*delta1(k)/delta2(k);
        vr_flag(k) = RSS(k) < Rcrit;
    end
end


%% ------------------------ Print summary --------------------------------
fprintf('Slope threshold b_max     = %.4f mol/L/min\n', b_max);
fprintf('Variance ratio threshold  = %.4f\n', Rcrit);

%% ------------------------ Plots ----------------------------------------
% 1) Main process variable
figure('Name','CSTR signal and SS detection','Color','w');
plot(t, CA, 'b-', 'LineWidth', 1.8); hold on;
plot(t, z, 'k.', 'MarkerSize', 8);

yl = ylim;
plot([t_step t_step], yl, 'r--', 'LineWidth', 1.2);

xlabel('Time [min]');
ylabel('C_A [mol/L]');
title('Simulated CSTR measurement and steady-state classification');
legend('True C_A','Measured z_k','Input step','Location','best');
grid on;

% 2) Slope test
figure('Name','Slope test','Color','w');
plot(t, slope, 'b-', 'LineWidth', 1.5); hold on;
yline(+b_max, 'r--', 'LineWidth', 1.2);
yline(-b_max, 'r--', 'LineWidth', 1.2);
plot([t_step t_step], ylim, 'k--', 'LineWidth', 1.0);
xlabel('Time [min]');
ylabel('Slope estimate');
title('Slope test');
legend('Estimated slope','Thresholds_{bmax}','Thresholds_{bmin}','Input step','Location','best');
grid on;

% 3) Variance ratio
figure('Name','Variance ratio test','Color','w');
plot(t, RSS, 'm-', 'LineWidth', 1.5); hold on;
yline(Rcrit, 'r--', 'LineWidth', 1.2);
plot([t_step t_step], ylim, 'k--', 'LineWidth', 1.0);
xlabel('Time [min]');
ylabel('R_{SS}');
title('Filtered variance ratio test');
legend('R_{SS}','R_{crit}','Input step','Location','best');
grid on;


%% ------------------------ Optional table output -------------------------
results = table(t, CA, z, slope, RSS, slope_flag, vr_flag);
disp(results);

%% ------------------------ Local functions -------------------------------
function dxdt = cstr_ode(t, x, p, t_step)
    CA = x(1);
    T  = x(2);

    if t < t_step
        CAin = p.CAin1;
    else
        CAin = p.CAin2;
    end

    k = p.k0 * exp(-p.E_R / T);
    rA = k * CA;

    dCAdt = (p.F/p.V)*(CAin - CA) - rA;

    dTdt = (p.F/p.V)*(p.Tin - T) ...
         + (-p.dH/p.rhoCp)*rA ...
         - (p.UA/(p.rhoCp*p.V))*(T - p.Tc);

    dxdt = [dCAdt; dTdt];
end